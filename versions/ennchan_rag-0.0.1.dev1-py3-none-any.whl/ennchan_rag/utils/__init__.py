"""Utility functions."""

from ennchan_rag.utils.validators import is_url, is_local_path
