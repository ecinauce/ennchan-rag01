"""Document loaders for various sources."""

from ennchan_rag.loaders.web import WebLoaderAdapter
from ennchan_rag.loaders.text import TextLoaderAdapter
# from ennchan_rag.loaders.string import StringLoaderAdapter
